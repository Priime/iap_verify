require 'venice'
require 'iap_verify/receipt_ios7'
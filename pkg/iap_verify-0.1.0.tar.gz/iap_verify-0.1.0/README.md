WFiapVerify
===========

Verify in app purchase gem
